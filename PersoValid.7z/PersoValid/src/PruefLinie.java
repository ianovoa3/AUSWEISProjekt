
public class PruefLinie {
	
	final String fuellZeichen = ">";
	public  PruefLinie(String ersteLinie,String zweiteLinie, String dritteLinie){
		
		 liniepruefen(ersteLinie,zweiteLinie,dritteLinie);
	}
	
	public void liniepruefen(String Linie1,String Linie2,String Linie3) {
		
		if(pruefersteLinie(Linie1)) {
			
		}
		
	}
	
	public boolean pruefersteLinie(String Linie1) {
		
		boolean operation = false;
		String substrings = "";
		
		try {
			substrings = Linie1.substring(0, 2);
			if(substrings.equals("IDD")) {
				substrings = Linie1.substring(3,4);
				if(substrings.equals(fuellZeichen)) {
					substrings = Linie1.substring(5,13);
					if(pruefPerso(substrings)) {
						
					}
				}
			
			}else {
				operation = false;
			}
			
		} catch (Exception e) {
			operation = false;
		}
		
		return operation;
		
	}
	
	
	public boolean pruefPerso(String personum) {
		boolean operation = false;
		String [] ArrayBuchstab = {"A","E","I","O","U","�","�","�","a","e","i","o","u","�","�","�","�","B","D","Q","S","b","d","q","s"};
		String substringPerso = "";
		try {
			substringPerso = personum.substring(0);
			
		} catch (Exception e) {
			
		}
		
		
	}

}
