
public class Personalausweisnummer {

	String ersteLinie;
	String zweiteLinie;
	String dritteLinie;
	
	
	public Personalausweisnummer(String line1, String line2, String line3) {
		ersteLinie  = line1;
		zweiteLinie = line2;
	}

	public Object getGebDat() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getAblDat() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getSerial() {
		// TODO Auto-generated method stub
		return null;
	}

}
